# Cloud Based Blood Bank Management System

This is Javafx based desktop application with back-end made in java and MySQL used as the DBMS, hosted on AWS

## For complete documentation of the project click [here](https://drive.google.com/file/d/1xhScoxv2HvuMx0gOPWxRqGMxMLZKCGeA/view?usp=sharing)
